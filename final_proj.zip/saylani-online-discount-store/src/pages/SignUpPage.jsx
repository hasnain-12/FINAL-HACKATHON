import { Heading } from '@chakra-ui/react'
import React from 'react'

export default function SignUpPage() {
  return (
    <div>
        <Heading>
            Sign Up
        </Heading>
    </div>
  )
}
