import { Heading } from "@chakra-ui/react";

export default function CartPage() {
  return (
    <div>
      <Heading>Cart</Heading>
    </div>
  );
}
