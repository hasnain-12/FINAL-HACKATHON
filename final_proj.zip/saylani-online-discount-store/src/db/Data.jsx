import React from "react";

export default function Data() {
  const Meat = [
    {
      title: "Mutton",
      img: "https://unsplash.com/photos/Xedxbjx7MFg/download?ixid=MnwxMjA3fDB8MXxhbGx8fHx8fHx8fHwxNjc2MTg3ODg4&force=true&w=1920",
      price: "100 PKR",
    },
    {
      title: "Mutton",
      img: "https://unsplash.com/photos/Xedxbjx7MFg/download?ixid=MnwxMjA3fDB8MXxhbGx8fHx8fHx8fHwxNjc2MTg3ODg4&force=true&w=1920",
      price: "100 PKR",
    },
    {
      title: "Mutton",
      img: "https://unsplash.com/photos/Xedxbjx7MFg/download?ixid=MnwxMjA3fDB8MXxhbGx8fHx8fHx8fHwxNjc2MTg3ODg4&force=true&w=1920",
      price: "100 PKR",
    },
  ];

  const Vegetables = [
    {
      title: "Mutton",
      img: "https://unsplash.com/photos/Xedxbjx7MFg/download?ixid=MnwxMjA3fDB8MXxhbGx8fHx8fHx8fHwxNjc2MTg3ODg4&force=true&w=1920",
      price: "100 PKR",
    },
    {
      title: "Mutton",
      img: "https://unsplash.com/photos/Xedxbjx7MFg/download?ixid=MnwxMjA3fDB8MXxhbGx8fHx8fHx8fHwxNjc2MTg3ODg4&force=true&w=1920",
      price: "100 PKR",
    },
    {
      title: "Mutton",
      img: "https://unsplash.com/photos/Xedxbjx7MFg/download?ixid=MnwxMjA3fDB8MXxhbGx8fHx8fHx8fHwxNjc2MTg3ODg4&force=true&w=1920",
      price: "100 PKR",
    },
  ];

  const Frozen = [
    {
      title: "Mutton",
      img: "https://unsplash.com/photos/Xedxbjx7MFg/download?ixid=MnwxMjA3fDB8MXxhbGx8fHx8fHx8fHwxNjc2MTg3ODg4&force=true&w=1920",
      price: "100 PKR",
    },
    {
      title: "Mutton",
      img: "https://unsplash.com/photos/Xedxbjx7MFg/download?ixid=MnwxMjA3fDB8MXxhbGx8fHx8fHx8fHwxNjc2MTg3ODg4&force=true&w=1920",
      price: "100 PKR",
    },
    {
      title: "Mutton",
      img: "https://unsplash.com/photos/Xedxbjx7MFg/download?ixid=MnwxMjA3fDB8MXxhbGx8fHx8fHx8fHwxNjc2MTg3ODg4&force=true&w=1920",
      price: "100 PKR",
    },
  ];

  const Beverages = [
    {
      title: "Mutton",
      img: "https://unsplash.com/photos/Xedxbjx7MFg/download?ixid=MnwxMjA3fDB8MXxhbGx8fHx8fHx8fHwxNjc2MTg3ODg4&force=true&w=1920",
      price: "100 PKR",
    },
    {
      title: "Mutton",
      img: "https://unsplash.com/photos/Xedxbjx7MFg/download?ixid=MnwxMjA3fDB8MXxhbGx8fHx8fHx8fHwxNjc2MTg3ODg4&force=true&w=1920",
      price: "100 PKR",
    },
    {
      title: "Mutton",
      img: "https://unsplash.com/photos/Xedxbjx7MFg/download?ixid=MnwxMjA3fDB8MXxhbGx8fHx8fHx8fHwxNjc2MTg3ODg4&force=true&w=1920",
      price: "100 PKR",
    },
  ];

  const Snacks = [
    {
      title: "Mutton",
      img: "https://unsplash.com/photos/Xedxbjx7MFg/download?ixid=MnwxMjA3fDB8MXxhbGx8fHx8fHx8fHwxNjc2MTg3ODg4&force=true&w=1920",
      price: "100 PKR",
    },
    {
      title: "Mutton",
      img: "https://unsplash.com/photos/Xedxbjx7MFg/download?ixid=MnwxMjA3fDB8MXxhbGx8fHx8fHx8fHwxNjc2MTg3ODg4&force=true&w=1920",
      price: "100 PKR",
    },
    {
      title: "Mutton",
      img: "https://unsplash.com/photos/Xedxbjx7MFg/download?ixid=MnwxMjA3fDB8MXxhbGx8fHx8fHx8fHwxNjc2MTg3ODg4&force=true&w=1920",
      price: "100 PKR",
    },
  ];

  const Beauty = [
    {
      title: "Mutton",
      img: "https://unsplash.com/photos/Xedxbjx7MFg/download?ixid=MnwxMjA3fDB8MXxhbGx8fHx8fHx8fHwxNjc2MTg3ODg4&force=true&w=1920",
      price: "100 PKR",
    },
    {
      title: "Mutton",
      img: "https://unsplash.com/photos/Xedxbjx7MFg/download?ixid=MnwxMjA3fDB8MXxhbGx8fHx8fHx8fHwxNjc2MTg3ODg4&force=true&w=1920",
      price: "100 PKR",
    },
    {
      title: "Mutton",
      img: "https://unsplash.com/photos/Xedxbjx7MFg/download?ixid=MnwxMjA3fDB8MXxhbGx8fHx8fHx8fHwxNjc2MTg3ODg4&force=true&w=1920",
      price: "100 PKR",
    },
  ];

  const Baby = [
    {
      title: "Mutton",
      img: "https://unsplash.com/photos/Xedxbjx7MFg/download?ixid=MnwxMjA3fDB8MXxhbGx8fHx8fHx8fHwxNjc2MTg3ODg4&force=true&w=1920",
      price: "100 PKR",
    },
    {
      title: "Mutton",
      img: "https://unsplash.com/photos/Xedxbjx7MFg/download?ixid=MnwxMjA3fDB8MXxhbGx8fHx8fHx8fHwxNjc2MTg3ODg4&force=true&w=1920",
      price: "100 PKR",
    },
    {
      title: "Mutton",
      img: "https://unsplash.com/photos/Xedxbjx7MFg/download?ixid=MnwxMjA3fDB8MXxhbGx8fHx8fHx8fHwxNjc2MTg3ODg4&force=true&w=1920",
      price: "100 PKR",
    },
  ];

  const BestSellings = [
    {
      title: "Mutton",
      img: "https://unsplash.com/photos/Xedxbjx7MFg/download?ixid=MnwxMjA3fDB8MXxhbGx8fHx8fHx8fHwxNjc2MTg3ODg4&force=true&w=1920",
      price: "100 PKR",
    },
    {
      title: "Mutton",
      img: "https://unsplash.com/photos/Xedxbjx7MFg/download?ixid=MnwxMjA3fDB8MXxhbGx8fHx8fHx8fHwxNjc2MTg3ODg4&force=true&w=1920",
      price: "100 PKR",
    },
    {
      title: "Mutton",
      img: "https://unsplash.com/photos/Xedxbjx7MFg/download?ixid=MnwxMjA3fDB8MXxhbGx8fHx8fHx8fHwxNjc2MTg3ODg4&force=true&w=1920",
      price: "100 PKR",
    },
  ];
  return <div></div>;
}
