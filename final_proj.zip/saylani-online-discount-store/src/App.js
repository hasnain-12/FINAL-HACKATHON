import Layout from "./rootLayout/Layout";

function App() {
  return <Layout />;
}

export default App;
